"""Foundation tests."""
