"""Temporal reconstruction."""
